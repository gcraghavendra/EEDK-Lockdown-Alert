Add-Type -AssemblyName PresentationFramework

# 1. Get the Real Logged-in User via Explorer Process
# Method: Since the popup is visible, explorer.exe must be running.
# We query the 'Owner' of the explorer.exe process to find the true human user.
try {
    $ExplorerProc = Get-WmiObject Win32_Process -Filter "Name='explorer.exe'" | Select-Object -First 1
    if ($ExplorerProc) {
        $OwnerInfo = $ExplorerProc.GetOwner()
        if ($OwnerInfo.User) {
            $CurrentUserName = $OwnerInfo.User
        } else {
            $CurrentUserName = "User"
        }
    } else {
        $CurrentUserName = "User"
    }
}
catch {
    # Fallback if detection completely fails
    $CurrentUserName = "User"
}

# Lockdown message text
$text = @"
Hi $CurrentUserName,

The PC you are using has been identified with malware and will be placed in lockdown shortly to protect your data and the network.

Thank you!

Raghavendra G C (RGC)
"@

# Popup title
$title = "Technical Support - LOCKDOWN NOTICE"

# Show popup with OK button and Warning icon
[System.Windows.MessageBox]::Show($text, $title, "OK", "Warning") | Out-Null