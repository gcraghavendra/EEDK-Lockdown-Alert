@echo off
setlocal ENABLEEXTENSIONS ENABLEDELAYEDEXPANSION

:: -------------------------------------------------------------------
:: 1. Setup Logging & Context
:: -------------------------------------------------------------------
pushd "%~dp0"

:: Create Log Directory if missing
if not exist "C:\Windows\Temp\McAfeeLogs" mkdir "C:\Windows\Temp\McAfeeLogs"

:: Generate Safe Date String for Filename (Removes slashes / and spaces)
set "SAFE_DATE=%DATE%"
set "SAFE_DATE=!SAFE_DATE:/=-!"
set "SAFE_DATE=!SAFE_DATE: =_!"

:: Define Log File Path
set "LOGFILE=C:\Windows\Temp\McAfeeLogs\%COMPUTERNAME%_Lockdown_!SAFE_DATE!.txt"

:: Start Logging
call :Log "--------------------------------------------------------"
call :Log "SCRIPT START: Lockdown Alert Sequence"
call :Log "Context: Running as %USERNAME% on %COMPUTERNAME%"
call :Log "Source Dir: %~dp0"

:: -------------------------------------------------------------------
:: 2. Identify PowerShell Path (Fixed for 64-bit ServiceUI)
:: -------------------------------------------------------------------
:: Check if we are in 32-bit mode on 64-bit OS (WOW64)
if exist "%windir%\sysnative\WindowsPowerShell\v1.0\powershell.exe" (
    REM We are in WOW64.
    REM CRITICAL FIX: Even though we are 32-bit, ServiceUI is 64-bit.
    REM ServiceUI cannot see 'sysnative'. We must pass 'System32'.
    REM ServiceUI x64 will resolve 'System32' to the real 64-bit folder correctly.
    set "PS=%windir%\System32\WindowsPowerShell\v1.0\powershell.exe"
    call :Log "INFO: 64-bit OS (WOW64) detected. Passing System32 path to x64 ServiceUI."
) else (
    REM We are in native 64-bit or 32-bit. System32 is correct.
    set "PS=%windir%\System32\WindowsPowerShell\v1.0\powershell.exe"
    call :Log "INFO: Native Architecture detected. Using System32 PowerShell."
)

:: -------------------------------------------------------------------
:: 3. Check for Logged-In User (Explorer.exe)
:: -------------------------------------------------------------------
tasklist /FI "IMAGENAME eq explorer.exe" | find /i "explorer.exe" >nul
if %errorlevel% NEQ 0 (
    call :Log "FAILURE: No user logged in (explorer.exe not found)."
    call :Log "ACTION: Exiting script to avoid background hang."
    goto EndScript
) else (
    call :Log "SUCCESS: User session found (explorer.exe is running)."
)

:: -------------------------------------------------------------------
:: 4. Verify Files Exist
:: -------------------------------------------------------------------
if not exist "%~dp0ServiceUI.exe" (
    call :Log "CRITICAL ERROR: ServiceUI.exe is missing from package."
    goto EndScript
)
if not exist "%~dp0LockdownAlert.ps1" (
    call :Log "CRITICAL ERROR: LockdownAlert.ps1 is missing from package."
    goto EndScript
)

:: -------------------------------------------------------------------
:: 5. Execute Payload via ServiceUI
:: -------------------------------------------------------------------
call :Log "ACTION: Launching PowerShell Alert via ServiceUI..."
call :Log "DEBUG: Target PowerShell: %PS%"

"%~dp0ServiceUI.exe" -process:explorer.exe "%PS%" -NoProfile -ExecutionPolicy Bypass -File "%~dp0LockdownAlert.ps1"
set "RC=%ERRORLEVEL%"

if %RC% EQU 0 (
    call :Log "SUCCESS: PowerShell script executed and closed correctly."
) else (
    call :Log "WARNING: PowerShell script exited with non-zero code: %RC%"
)

:EndScript
call :Log "SCRIPT FINISHED"
call :Log "--------------------------------------------------------"
popd
exit /b %RC%

:: -------------------------------------------------------------------
:: Helper: Logging Function
:: -------------------------------------------------------------------
:Log
:: Print to Screen (for testing)
echo %~1
:: Print to File (for record)
echo %DATE% %TIME% : %~1 >> "%LOGFILE%"
exit /b